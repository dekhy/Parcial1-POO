/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import model.Programador;

/**
 *
 * @author crfranco
 */
public class MemoryDataBank implements IDao<Programador> {

	private List<Programador> memoryDataBank = new ArrayList<>();

	@Override
	public void save(Programador t) {
		System.out.print(memoryDataBank);
		if (!memoryDataBank.contains(t))
			memoryDataBank.add(t);
		System.out.println(memoryDataBank);
	}

	@Override
	public Programador getOne(int id) {
		return memoryDataBank.get(id);
	}

	@Override
	public List<Programador> list() {
		throw new UnsupportedOperationException("Not supported yet."); // To change body of generated methods, choos
	}

	@Override
	public void update(Programador t) {
		memoryDataBank.remove(t);
		memoryDataBank.add(t);
	}

	@Override
	public void delete(int id) {

	}


}
